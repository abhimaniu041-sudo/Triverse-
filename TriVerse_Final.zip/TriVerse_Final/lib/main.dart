import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:provider/provider.dart';
import 'firebase_options.dart';
import 'screens/splash_screen.dart';
import 'screens/login_screen.dart';
import 'screens/main_layout.dart';
import 'providers/app_state.dart';
import 'services/fcm_service.dart';

/// Global flag — true when Firebase successfully initialized.
/// Lets the UI render a helpful banner instead of a hard crash on misconfigured builds.
bool firebaseReady = false;
String? firebaseInitError;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  try {
    await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
    firebaseReady = true;
  } catch (e) {
    firebaseInitError = e.toString();
    firebaseReady = false;
    // Continue — the app will still launch so the user can see the splash + a config hint.
  }

  if (firebaseReady) {
    try {
      await FcmService.init();
    } catch (_) {
      // non-fatal
    }
  }

  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppState()),
      ],
      child: const TriVerseApp(),
    ),
  );
}

class TriVerseApp extends StatelessWidget {
  const TriVerseApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TriVerse',
      debugShowCheckedModeBanner: false,
      navigatorKey: FcmService.navigatorKey,
      scaffoldMessengerKey: FcmService.scaffoldMessengerKey,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF0A0A1A),
        primaryColor: const Color(0xFFB026FF),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFFB026FF),
          secondary: Color(0xFF00E5FF),
          surface: Color(0xFF16162C),
        ),
      ),
      initialRoute: '/',
      routes: {
        '/': (context) => const SplashScreen(),
        '/login': (context) => const LoginScreen(),
        '/home': (context) => const MainLayout(),
      },
    );
  }
}
